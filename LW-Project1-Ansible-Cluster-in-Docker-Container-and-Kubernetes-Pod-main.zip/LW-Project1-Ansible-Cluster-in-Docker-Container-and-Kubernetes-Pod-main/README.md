# LW-Project1-Ansible-Cluster-in-Docker-Container-and-Kubernetes-Pod
